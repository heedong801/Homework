#pragma once

// �뵵 : 
// �з� :
// ÷�� : 
class $safeitemname$
{
private: // Member Var

public: // Default
	$safeitemname$();
	~$safeitemname$();

	$safeitemname$(const $safeitemname$& _Other) = delete;
	$safeitemname$($safeitemname$&& _Other) noexcept;

protected:
	$safeitemname$& operator=(const $safeitemname$& _Other) = delete;
	$safeitemname$& operator=($safeitemname$&& _Other) = delete;

private:

public: // Member Function
};

